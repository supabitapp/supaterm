export type NormalizedMarkdownShortcuts = {
    heading: boolean;
    unorderedList: boolean;
    orderedList: boolean;
};
export declare const normalizeMarkdownShortcuts: (raw: unknown) => NormalizedMarkdownShortcuts;
//# sourceMappingURL=normalizeMarkdownShortcuts.d.ts.map