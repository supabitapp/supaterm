import type { ASTNode } from './types';
export declare function recognizeTextLinks(ast: ASTNode, textLinkRegex: RegExp | undefined, inlineCodeLinkRegex: RegExp | undefined): ASTNode;
//# sourceMappingURL=recognizeTextLinks.d.ts.map